using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CanvasBehavior : MonoBehaviour
{
    [SerializeField] Text ScoreText;
    [SerializeField] Text AmmoText;

    [SerializeField] Button RestartButton;
    [SerializeField] Button MainMenuButton;

    [SerializeField] GameObject Player;

    private void Start()
    {
        RestartButton.onClick.AddListener(Restart);
        MainMenuButton.onClick.AddListener(MainMenu);
    }

    private void Update()
    {
        ScoreText.text = "Score: " + Mathf.FloorToInt(Time.timeSinceLevelLoad);
        AmmoText.text = "Ammo: " + Player.GetComponent<Player>().Ammo;
    }

    void Restart()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene("MainGame");
    }

    void MainMenu()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene("MainMenu");
    }
}
