using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField] Transform Bullet;
    [SerializeField] GameObject DeathMenu;

    public int Ammo;

    private void Update()
    {
        if (Time.timeScale > 0)
        {
            Vector3 worldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            transform.position = new Vector3(worldPos.x, -4.5f, 0);

            if (Input.GetKeyUp(KeyCode.Mouse0) && Ammo > 0)
            {
                var temp = Instantiate(Bullet, transform.position + new Vector3(0, .5f, 0), Quaternion.identity);
                temp.name = "Bullet";
                temp.GetComponent<Bullet>().player = gameObject;
                Ammo -= 1;
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Physics2D.IgnoreCollision(collision.collider, collision.otherCollider);

        if (collision.gameObject.name == "Squirrel")
        {
            DeathMenu.SetActive(true);
            Time.timeScale = 0;
        }
    }
}
