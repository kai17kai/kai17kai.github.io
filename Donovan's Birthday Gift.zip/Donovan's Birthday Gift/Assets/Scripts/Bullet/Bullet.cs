using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public GameObject player;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "Squirrel")
        {
            Destroy(collision.gameObject);
            player.GetComponent<Player>().Ammo += 1;
            Destroy(gameObject);
        }
        else
        {
            Physics2D.IgnoreCollision(collision.collider, collision.otherCollider);
        }
    }
}
