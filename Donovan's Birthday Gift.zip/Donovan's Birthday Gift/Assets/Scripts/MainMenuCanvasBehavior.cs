using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainMenuCanvasBehavior : MonoBehaviour
{
    //Main Menu and its Parts
    [SerializeField] GameObject MainMenu;
    [SerializeField] Button StartButton;
    [SerializeField] Button QuitButton;
    [SerializeField] Button ControlsMenuButton;

    //Controls Menu and its Parts
    [SerializeField] GameObject ControlsMenu;
    [SerializeField] Button BackToMainMenuButton;

    // Start is called before the first frame update
    void Start()
    {
        StartButton.onClick.AddListener(StartButtonAction);
        QuitButton.onClick.AddListener(QuitButtonAction);

        ControlsMenuButton.onClick.AddListener(SetUpControlsMenu);
        BackToMainMenuButton.onClick.AddListener(SetUpControlsMenu);
    }

    void StartButtonAction()
    {
        SceneManager.LoadScene("MainGame");
    }

    void QuitButtonAction()
    {
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
        #else
            Application.Quit();
        #endif
    }

    void SetUpControlsMenu()
    {
        MainMenu.SetActive(!MainMenu.activeSelf);
        ControlsMenu.SetActive(!MainMenu.activeSelf);
    }
}
