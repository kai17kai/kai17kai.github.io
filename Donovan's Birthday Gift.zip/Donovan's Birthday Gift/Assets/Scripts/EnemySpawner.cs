using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    float EnemyTime = 0;
    float MaxTime = 0;

    [SerializeField] Transform Squirrel;

    // Start is called before the first frame update
    void Start()
    {
        MaxTime = Random.Range(4f, 8f);
    }

    // Update is called once per frame
    void Update()
    {
        EnemyTime += Time.deltaTime;
        if (EnemyTime > MaxTime)
        {
            EnemyTime = 0;
            MaxTime = Random.Range(4f, 8f);
            int EnemyCount = Mathf.RoundToInt(.1f * Time.timeSinceLevelLoad + 1);
            for (int i = 0; i < EnemyCount; ++i)
            {
                var temp = Instantiate(Squirrel, new Vector3(Random.Range(-9.5f, 9.5f), 4.5f, 0), Quaternion.identity);
                temp.gameObject.name = "Squirrel";
            }
        }
    }
}
