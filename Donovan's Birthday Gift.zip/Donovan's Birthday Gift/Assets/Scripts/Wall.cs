using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{
    [SerializeField] GameObject DeathMenu;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        switch (collision.gameObject.name)
        {
            case "Bullet":
                Destroy(collision.gameObject);
                break;
            case "Squirrel":
                if (gameObject.name == "TopWall")
                {
                    Physics2D.IgnoreCollision(collision.collider, collision.otherCollider);
                }
                else
                {
                    Physics2D.IgnoreCollision(collision.collider, collision.otherCollider);
                    DeathMenu.SetActive(true);
                    Time.timeScale = 0;
                }
                break;
        }
    }
}
